"""
Módulo de utilidades comunes para Scientific Article Aggregator
"""

