"""
Módulo de knowledge graph para visualizar relaciones entre artículos científicos
"""

