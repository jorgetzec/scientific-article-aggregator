"""
Módulo de recolección de datos de APIs científicas
"""

