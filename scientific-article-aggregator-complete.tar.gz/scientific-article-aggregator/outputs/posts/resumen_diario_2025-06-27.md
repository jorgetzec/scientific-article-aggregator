# Resumen Científico Diario - 27 de June, 2025

Hoy se procesaron **3 artículos** de diversas fuentes científicas.

## Artículos por Fuente

### Arxiv (3 artículos)

- **Devising a solution to the problems of Cancer awareness in Telangana**
  Este estudio científico According to the data, the percent of women who underwent screening for cerv...

- **Counterfactual Voting Adjustment for Quality Assessment and Fairer Voting in Online Platforms with Helpfulness Evaluation**
  Esta investigación de inteligencia artificial To promote more useful information, users not only cre...

- **Bayesian Modeling for Aggregated Relational Data: A Unified Perspective**
  Este estudio científico Aggregated relational data is widely collected to study social network theor...

## Temas Más Frecuentes

- cs.LG: 1 artículos
- cs.CY: 1 artículos
- q-bio.QM: 1 artículos
- cs.CE: 1 artículos
- stat.ME: 1 artículos

## Estadísticas

- Total de artículos procesados: 3
- Fuentes consultadas: 1
- Artículos con resumen: 3
- Posts divulgativos generados: 3

*Generado automáticamente el 2025-06-27 12:06:20*