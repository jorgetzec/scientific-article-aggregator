# Scientific Article Aggregator

Una aplicación web automatizada que escanea artículos científicos de múltiples bases de datos, genera resúmenes y posts divulgativos sobre temas de interés específicos, incluye un knowledge graph, y permite guardar contenido en formato markdown con ejecución automática diaria.

## Características

- **Múltiples Fuentes de Datos**: Integración con The Lens, IEEE Xplore, arXiv, Europe PMC, DOAJ, bioRxiv/medRxiv, y Crossref Metadata API
- **Procesamiento Inteligente**: Generación automática de resúmenes sin tecnicismos y posts divulgativos
- **Knowledge Graph**: Visualización de relaciones entre conceptos, autores e instituciones
- **Interfaz Web**: Aplicación Streamlit intuitiva similar a Feedly
- **Automatización**: Ejecución diaria automática para mantenerse actualizado
- **Exportación**: Guardado de posts en formato Markdown

## Temas de Interés Soportados

- Bioinformática
- Programación en biología
- Análisis de datos biológicos
- Interacción planta-microorganismos
- Educación científica
- Investigación en divulgación de la ciencia

## Estructura del Proyecto

```
scientific-article-aggregator/
├── src/
│   ├── data_harvester/     # Recolección de datos de APIs
│   ├── article_processor/  # Procesamiento y generación de contenido
│   ├── knowledge_graph/    # Construcción y visualización del grafo
│   ├── scheduler/          # Automatización de tareas
│   └── utils/              # Utilidades comunes
├── streamlit_app/          # Interfaz web Streamlit
├── data/                   # Almacenamiento de datos
├── outputs/                # Posts generados en markdown
├── config/                 # Archivos de configuración
├── tests/                  # Pruebas unitarias
├── requirements.txt        # Dependencias Python
└── README.md              # Este archivo
```

## Instalación

```bash
# Clonar el repositorio
git clone https://github.com/tu-usuario/scientific-article-aggregator.git
cd scientific-article-aggregator

# Instalar dependencias
pip install -r requirements.txt

# Configurar APIs (ver config/api_keys.example.yaml)
cp config/api_keys.example.yaml config/api_keys.yaml
# Editar config/api_keys.yaml con tus claves de API
```

## Uso

### Ejecutar la aplicación Streamlit

```bash
streamlit run streamlit_app/main.py
```

### Ejecutar manualmente la recolección de artículos

```bash
python src/main.py --topics "bioinformática,programación en biología"
```

### Configurar la automatización diaria

```bash
python src/scheduler/daily_runner.py
```

## Configuración

Edita `config/settings.yaml` para personalizar:
- Temas de interés
- Frecuencia de ejecución
- Configuración de APIs
- Parámetros de procesamiento de texto

## Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## Contacto

Tu Nombre - tu.email@ejemplo.com

Enlace del Proyecto: [https://github.com/tu-usuario/scientific-article-aggregator](https://github.com/tu-usuario/scientific-article-aggregator)

